#include <stdio.h>
void binary_search();
 
int a[20], n, item, loc, front, mid, end, i;
void main()
{
    printf("\nEnter the size: ");
    scanf("%d", &n);
    printf("\nEnter elements of an array in sorted form:\n");
    for(i=0; i<n; i++)
        scanf("%d", &a[i]);
    printf("\nEnter item to be searched: ");
    scanf("%d", &item);
    binary_search();
    getch();
}
void binary_search()
{
    front = 0;
    end = n-1;
    mid = (front + end) / 2;
    while ((front<=end) && (a[mid]!=item))
    {
        if (item < a[mid])
            end = mid - 1;
        else
            front = mid + 1;
        mid = (front + end) / 2;
    }
    if (a[mid] == item)
        printf("\n\nitem found at its place %d", mid+1);
    else
        printf("\n\nitem doesn't exist");
}